/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QStackedWidget *MainStackWidget;
    QWidget *Mpage1;
    QLabel *UsernamLabel;
    QLabel *PwdLabel;
    QPushButton *LoginButton;
    QLineEdit *UsernameLE;
    QLineEdit *PwdLE;
    QWidget *Mpage2;
    QStackedWidget *StudentStackWidget;
    QWidget *Studpage0;
    QLabel *StudentWelcomLabel;
    QPushButton *ViewInfoButton;
    QPushButton *logoutButton;
    QListWidget *StudClassListWidget;
    QLabel *StudClassListWlabel;
    QLabel *StudNameLabelMP;
    QLabel *StudentIDlabelMP;
    QGroupBox *StudGroupBox;
    QWidget *Studpage1;
    QLabel *StudInfoLabel;
    QPushButton *Studbackbutton1;
    QWidget *Mpage3;
    QStackedWidget *InstructorStackWidget;
    QWidget *Instpage0_2;
    QListWidget *InstClassListWidget;
    QListWidget *InstStudListWidget;
    QLabel *InstNameLabel;
    QLabel *InstIDlabel;
    QLabel *InstSelectCourseLabel;
    QLabel *InstStudListLabel;
    QPushButton *InstLogoutButton;
    QPushButton *InstInfoButton;
    QLabel *InstWelcomePageLabel;
    QWidget *Instpage1;
    QLabel *InstructorWelcomLabel;
    QPushButton *InstBackButton;
    QWidget *Mpage4;
    QStackedWidget *AdminStackedWidget;
    QWidget *Admipage0;
    QLabel *AdminWelcomePageLabel;
    QListWidget *AdmStudListWidget;
    QListWidget *AdmInstListWidget;
    QListWidget *AdmClassListWidget;
    QPushButton *AdminLogoutButton;
    QLabel *AdminNameLabel;
    QLabel *AmdinIDlabel;
    QPushButton *AdmStudVInfoButton;
    QPushButton *AdmStuADDbutton;
    QPushButton *AdmStudDELbutton;
    QPushButton *AdmStudVClassButton;
    QLabel *AdminStudListLabel;
    QPushButton *AdmInstADDbutton;
    QPushButton *AdmInstDELbutton;
    QPushButton *AdmInstVClassButton;
    QPushButton *AdmInstVInfoButton;
    QLabel *AdminInstListLabel;
    QLabel *AmdinClassListLabel;
    QPushButton *AdmClassADDbutton;
    QPushButton *AdmClassDELbutton;
    QPushButton *AdmClassVInfo;
    QWidget *Admipage1;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(786, 502);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        MainStackWidget = new QStackedWidget(centralWidget);
        MainStackWidget->setObjectName(QStringLiteral("MainStackWidget"));
        MainStackWidget->setGeometry(QRect(20, 10, 751, 431));
        Mpage1 = new QWidget();
        Mpage1->setObjectName(QStringLiteral("Mpage1"));
        UsernamLabel = new QLabel(Mpage1);
        UsernamLabel->setObjectName(QStringLiteral("UsernamLabel"));
        UsernamLabel->setGeometry(QRect(150, 130, 91, 16));
        PwdLabel = new QLabel(Mpage1);
        PwdLabel->setObjectName(QStringLiteral("PwdLabel"));
        PwdLabel->setGeometry(QRect(150, 200, 111, 16));
        LoginButton = new QPushButton(Mpage1);
        LoginButton->setObjectName(QStringLiteral("LoginButton"));
        LoginButton->setGeometry(QRect(320, 290, 113, 32));
        UsernameLE = new QLineEdit(Mpage1);
        UsernameLE->setObjectName(QStringLiteral("UsernameLE"));
        UsernameLE->setGeometry(QRect(460, 120, 113, 21));
        PwdLE = new QLineEdit(Mpage1);
        PwdLE->setObjectName(QStringLiteral("PwdLE"));
        PwdLE->setGeometry(QRect(460, 190, 113, 21));
        MainStackWidget->addWidget(Mpage1);
        Mpage2 = new QWidget();
        Mpage2->setObjectName(QStringLiteral("Mpage2"));
        StudentStackWidget = new QStackedWidget(Mpage2);
        StudentStackWidget->setObjectName(QStringLiteral("StudentStackWidget"));
        StudentStackWidget->setGeometry(QRect(0, 20, 751, 391));
        Studpage0 = new QWidget();
        Studpage0->setObjectName(QStringLiteral("Studpage0"));
        StudentWelcomLabel = new QLabel(Studpage0);
        StudentWelcomLabel->setObjectName(QStringLiteral("StudentWelcomLabel"));
        StudentWelcomLabel->setGeometry(QRect(290, 20, 181, 20));
        ViewInfoButton = new QPushButton(Studpage0);
        ViewInfoButton->setObjectName(QStringLiteral("ViewInfoButton"));
        ViewInfoButton->setGeometry(QRect(220, 350, 351, 32));
        logoutButton = new QPushButton(Studpage0);
        logoutButton->setObjectName(QStringLiteral("logoutButton"));
        logoutButton->setGeometry(QRect(650, 20, 71, 32));
        StudClassListWidget = new QListWidget(Studpage0);
        StudClassListWidget->setObjectName(QStringLiteral("StudClassListWidget"));
        StudClassListWidget->setGeometry(QRect(60, 121, 256, 201));
        StudClassListWlabel = new QLabel(Studpage0);
        StudClassListWlabel->setObjectName(QStringLiteral("StudClassListWlabel"));
        StudClassListWlabel->setGeometry(QRect(140, 100, 101, 16));
        StudNameLabelMP = new QLabel(Studpage0);
        StudNameLabelMP->setObjectName(QStringLiteral("StudNameLabelMP"));
        StudNameLabelMP->setGeometry(QRect(10, 20, 171, 16));
        StudentIDlabelMP = new QLabel(Studpage0);
        StudentIDlabelMP->setObjectName(QStringLiteral("StudentIDlabelMP"));
        StudentIDlabelMP->setGeometry(QRect(10, 40, 171, 16));
        StudGroupBox = new QGroupBox(Studpage0);
        StudGroupBox->setObjectName(QStringLiteral("StudGroupBox"));
        StudGroupBox->setGeometry(QRect(400, 99, 361, 221));
        QFont font;
        font.setPointSize(14);
        StudGroupBox->setFont(font);
        StudGroupBox->setFlat(false);
        StudGroupBox->setCheckable(false);
        StudGroupBox->setChecked(false);
        StudentStackWidget->addWidget(Studpage0);
        Studpage1 = new QWidget();
        Studpage1->setObjectName(QStringLiteral("Studpage1"));
        StudInfoLabel = new QLabel(Studpage1);
        StudInfoLabel->setObjectName(QStringLiteral("StudInfoLabel"));
        StudInfoLabel->setGeometry(QRect(320, 40, 111, 16));
        Studbackbutton1 = new QPushButton(Studpage1);
        Studbackbutton1->setObjectName(QStringLiteral("Studbackbutton1"));
        Studbackbutton1->setGeometry(QRect(30, 350, 113, 32));
        StudentStackWidget->addWidget(Studpage1);
        MainStackWidget->addWidget(Mpage2);
        Mpage3 = new QWidget();
        Mpage3->setObjectName(QStringLiteral("Mpage3"));
        InstructorStackWidget = new QStackedWidget(Mpage3);
        InstructorStackWidget->setObjectName(QStringLiteral("InstructorStackWidget"));
        InstructorStackWidget->setGeometry(QRect(-10, 20, 761, 391));
        Instpage0_2 = new QWidget();
        Instpage0_2->setObjectName(QStringLiteral("Instpage0_2"));
        InstClassListWidget = new QListWidget(Instpage0_2);
        InstClassListWidget->setObjectName(QStringLiteral("InstClassListWidget"));
        InstClassListWidget->setGeometry(QRect(80, 100, 256, 221));
        InstStudListWidget = new QListWidget(Instpage0_2);
        InstStudListWidget->setObjectName(QStringLiteral("InstStudListWidget"));
        InstStudListWidget->setGeometry(QRect(450, 100, 256, 211));
        InstNameLabel = new QLabel(Instpage0_2);
        InstNameLabel->setObjectName(QStringLiteral("InstNameLabel"));
        InstNameLabel->setGeometry(QRect(20, 10, 131, 16));
        InstIDlabel = new QLabel(Instpage0_2);
        InstIDlabel->setObjectName(QStringLiteral("InstIDlabel"));
        InstIDlabel->setGeometry(QRect(20, 40, 111, 16));
        InstSelectCourseLabel = new QLabel(Instpage0_2);
        InstSelectCourseLabel->setObjectName(QStringLiteral("InstSelectCourseLabel"));
        InstSelectCourseLabel->setGeometry(QRect(160, 80, 101, 16));
        InstStudListLabel = new QLabel(Instpage0_2);
        InstStudListLabel->setObjectName(QStringLiteral("InstStudListLabel"));
        InstStudListLabel->setGeometry(QRect(509, 80, 161, 20));
        InstLogoutButton = new QPushButton(Instpage0_2);
        InstLogoutButton->setObjectName(QStringLiteral("InstLogoutButton"));
        InstLogoutButton->setGeometry(QRect(650, 10, 71, 32));
        InstInfoButton = new QPushButton(Instpage0_2);
        InstInfoButton->setObjectName(QStringLiteral("InstInfoButton"));
        InstInfoButton->setGeometry(QRect(280, 350, 231, 32));
        InstWelcomePageLabel = new QLabel(Instpage0_2);
        InstWelcomePageLabel->setObjectName(QStringLiteral("InstWelcomePageLabel"));
        InstWelcomePageLabel->setGeometry(QRect(310, 10, 201, 16));
        InstructorStackWidget->addWidget(Instpage0_2);
        Instpage1 = new QWidget();
        Instpage1->setObjectName(QStringLiteral("Instpage1"));
        InstructorWelcomLabel = new QLabel(Instpage1);
        InstructorWelcomLabel->setObjectName(QStringLiteral("InstructorWelcomLabel"));
        InstructorWelcomLabel->setGeometry(QRect(290, 20, 201, 16));
        InstBackButton = new QPushButton(Instpage1);
        InstBackButton->setObjectName(QStringLiteral("InstBackButton"));
        InstBackButton->setGeometry(QRect(20, 350, 113, 32));
        InstructorStackWidget->addWidget(Instpage1);
        MainStackWidget->addWidget(Mpage3);
        Mpage4 = new QWidget();
        Mpage4->setObjectName(QStringLiteral("Mpage4"));
        AdminStackedWidget = new QStackedWidget(Mpage4);
        AdminStackedWidget->setObjectName(QStringLiteral("AdminStackedWidget"));
        AdminStackedWidget->setGeometry(QRect(0, 20, 751, 401));
        Admipage0 = new QWidget();
        Admipage0->setObjectName(QStringLiteral("Admipage0"));
        AdminWelcomePageLabel = new QLabel(Admipage0);
        AdminWelcomePageLabel->setObjectName(QStringLiteral("AdminWelcomePageLabel"));
        AdminWelcomePageLabel->setGeometry(QRect(300, 20, 171, 16));
        AdmStudListWidget = new QListWidget(Admipage0);
        AdmStudListWidget->setObjectName(QStringLiteral("AdmStudListWidget"));
        AdmStudListWidget->setGeometry(QRect(20, 120, 211, 192));
        AdmInstListWidget = new QListWidget(Admipage0);
        AdmInstListWidget->setObjectName(QStringLiteral("AdmInstListWidget"));
        AdmInstListWidget->setGeometry(QRect(280, 120, 211, 192));
        AdmClassListWidget = new QListWidget(Admipage0);
        AdmClassListWidget->setObjectName(QStringLiteral("AdmClassListWidget"));
        AdmClassListWidget->setGeometry(QRect(530, 120, 201, 192));
        AdminLogoutButton = new QPushButton(Admipage0);
        AdminLogoutButton->setObjectName(QStringLiteral("AdminLogoutButton"));
        AdminLogoutButton->setGeometry(QRect(660, 10, 71, 32));
        AdminNameLabel = new QLabel(Admipage0);
        AdminNameLabel->setObjectName(QStringLiteral("AdminNameLabel"));
        AdminNameLabel->setGeometry(QRect(20, 10, 121, 16));
        AmdinIDlabel = new QLabel(Admipage0);
        AmdinIDlabel->setObjectName(QStringLiteral("AmdinIDlabel"));
        AmdinIDlabel->setGeometry(QRect(20, 40, 121, 16));
        AdmStudVInfoButton = new QPushButton(Admipage0);
        AdmStudVInfoButton->setObjectName(QStringLiteral("AdmStudVInfoButton"));
        AdmStudVInfoButton->setGeometry(QRect(130, 350, 101, 32));
        AdmStuADDbutton = new QPushButton(Admipage0);
        AdmStuADDbutton->setObjectName(QStringLiteral("AdmStuADDbutton"));
        AdmStuADDbutton->setGeometry(QRect(20, 320, 111, 32));
        AdmStudDELbutton = new QPushButton(Admipage0);
        AdmStudDELbutton->setObjectName(QStringLiteral("AdmStudDELbutton"));
        AdmStudDELbutton->setGeometry(QRect(130, 320, 101, 32));
        AdmStudVClassButton = new QPushButton(Admipage0);
        AdmStudVClassButton->setObjectName(QStringLiteral("AdmStudVClassButton"));
        AdmStudVClassButton->setGeometry(QRect(20, 350, 111, 32));
        AdminStudListLabel = new QLabel(Admipage0);
        AdminStudListLabel->setObjectName(QStringLiteral("AdminStudListLabel"));
        AdminStudListLabel->setGeometry(QRect(70, 90, 111, 16));
        AdmInstADDbutton = new QPushButton(Admipage0);
        AdmInstADDbutton->setObjectName(QStringLiteral("AdmInstADDbutton"));
        AdmInstADDbutton->setGeometry(QRect(280, 320, 111, 32));
        AdmInstDELbutton = new QPushButton(Admipage0);
        AdmInstDELbutton->setObjectName(QStringLiteral("AdmInstDELbutton"));
        AdmInstDELbutton->setGeometry(QRect(390, 320, 101, 32));
        AdmInstVClassButton = new QPushButton(Admipage0);
        AdmInstVClassButton->setObjectName(QStringLiteral("AdmInstVClassButton"));
        AdmInstVClassButton->setGeometry(QRect(280, 350, 111, 32));
        AdmInstVInfoButton = new QPushButton(Admipage0);
        AdmInstVInfoButton->setObjectName(QStringLiteral("AdmInstVInfoButton"));
        AdmInstVInfoButton->setGeometry(QRect(390, 350, 101, 32));
        AdminInstListLabel = new QLabel(Admipage0);
        AdminInstListLabel->setObjectName(QStringLiteral("AdminInstListLabel"));
        AdminInstListLabel->setGeometry(QRect(330, 90, 131, 20));
        AmdinClassListLabel = new QLabel(Admipage0);
        AmdinClassListLabel->setObjectName(QStringLiteral("AmdinClassListLabel"));
        AmdinClassListLabel->setGeometry(QRect(590, 100, 91, 16));
        AdmClassADDbutton = new QPushButton(Admipage0);
        AdmClassADDbutton->setObjectName(QStringLiteral("AdmClassADDbutton"));
        AdmClassADDbutton->setGeometry(QRect(530, 320, 201, 32));
        AdmClassDELbutton = new QPushButton(Admipage0);
        AdmClassDELbutton->setObjectName(QStringLiteral("AdmClassDELbutton"));
        AdmClassDELbutton->setGeometry(QRect(530, 350, 101, 32));
        AdmClassVInfo = new QPushButton(Admipage0);
        AdmClassVInfo->setObjectName(QStringLiteral("AdmClassVInfo"));
        AdmClassVInfo->setGeometry(QRect(630, 350, 101, 32));
        AdminStackedWidget->addWidget(Admipage0);
        Admipage1 = new QWidget();
        Admipage1->setObjectName(QStringLiteral("Admipage1"));
        AdminStackedWidget->addWidget(Admipage1);
        MainStackWidget->addWidget(Mpage4);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 786, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        MainStackWidget->setCurrentIndex(2);
        StudentStackWidget->setCurrentIndex(0);
        InstructorStackWidget->setCurrentIndex(0);
        AdminStackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        UsernamLabel->setText(QApplication::translate("MainWindow", "Username", Q_NULLPTR));
        PwdLabel->setText(QApplication::translate("MainWindow", "Password", Q_NULLPTR));
        LoginButton->setText(QApplication::translate("MainWindow", "Log in", Q_NULLPTR));
        StudentWelcomLabel->setText(QApplication::translate("MainWindow", "Welcome to the student page", Q_NULLPTR));
        ViewInfoButton->setText(QApplication::translate("MainWindow", "View Info", Q_NULLPTR));
        logoutButton->setText(QApplication::translate("MainWindow", "logout", Q_NULLPTR));
        StudClassListWlabel->setText(QApplication::translate("MainWindow", "Select a course", Q_NULLPTR));
        StudNameLabelMP->setText(QApplication::translate("MainWindow", "Student name", Q_NULLPTR));
        StudentIDlabelMP->setText(QApplication::translate("MainWindow", "Student ID", Q_NULLPTR));
        StudGroupBox->setTitle(QApplication::translate("MainWindow", "Assignments and grades for the selected course", Q_NULLPTR));
        StudInfoLabel->setText(QApplication::translate("MainWindow", "Student info page", Q_NULLPTR));
        Studbackbutton1->setText(QApplication::translate("MainWindow", "back", Q_NULLPTR));
        InstNameLabel->setText(QApplication::translate("MainWindow", "Instructor's Name", Q_NULLPTR));
        InstIDlabel->setText(QApplication::translate("MainWindow", "Instructor's ID", Q_NULLPTR));
        InstSelectCourseLabel->setText(QApplication::translate("MainWindow", "Select a course", Q_NULLPTR));
        InstStudListLabel->setText(QApplication::translate("MainWindow", "List of tstudent per class", Q_NULLPTR));
        InstLogoutButton->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        InstInfoButton->setText(QApplication::translate("MainWindow", "View Info", Q_NULLPTR));
        InstWelcomePageLabel->setText(QApplication::translate("MainWindow", "Welcome to the instructor's page", Q_NULLPTR));
        InstructorWelcomLabel->setText(QApplication::translate("MainWindow", "Welcome to the Instructors Page", Q_NULLPTR));
        InstBackButton->setText(QApplication::translate("MainWindow", "Back", Q_NULLPTR));
        AdminWelcomePageLabel->setText(QApplication::translate("MainWindow", "Welcome to the admin page", Q_NULLPTR));
        AdminLogoutButton->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        AdminNameLabel->setText(QApplication::translate("MainWindow", "Admin's Name", Q_NULLPTR));
        AmdinIDlabel->setText(QApplication::translate("MainWindow", "Admin's ID", Q_NULLPTR));
        AdmStudVInfoButton->setText(QApplication::translate("MainWindow", "View Info", Q_NULLPTR));
        AdmStuADDbutton->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        AdmStudDELbutton->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        AdmStudVClassButton->setText(QApplication::translate("MainWindow", "View Classes", Q_NULLPTR));
        AdminStudListLabel->setText(QApplication::translate("MainWindow", "Select a Student", Q_NULLPTR));
        AdmInstADDbutton->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        AdmInstDELbutton->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        AdmInstVClassButton->setText(QApplication::translate("MainWindow", "View Classes", Q_NULLPTR));
        AdmInstVInfoButton->setText(QApplication::translate("MainWindow", "View Info", Q_NULLPTR));
        AdminInstListLabel->setText(QApplication::translate("MainWindow", "Select an Instructor", Q_NULLPTR));
        AmdinClassListLabel->setText(QApplication::translate("MainWindow", "Select a class", Q_NULLPTR));
        AdmClassADDbutton->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        AdmClassDELbutton->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        AdmClassVInfo->setText(QApplication::translate("MainWindow", "View Info", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
